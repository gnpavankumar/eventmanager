from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import (
    CollegeViewSet, StudentViewSet, AdminProfileViewSet, EventViewSet, RegistrationViewSet, FeedbackCreateAPIView,
    AttendanceCreateAPIView, EventPopularityReportAPIView, AttendancePercentageReportAPIView, AverageFeedbackReportAPIView
)

router = DefaultRouter()
router.register(r'colleges', CollegeViewSet)
router.register(r'students', StudentViewSet)
router.register(r'admins', AdminProfileViewSet)
router.register(r'events', EventViewSet)
router.register(r'registrations', RegistrationViewSet)

urlpatterns = [
    path('', include(router.urls)),
    path('attendance/', AttendanceCreateAPIView.as_view(), name='attendance-create'),
    path('feedback-create/', FeedbackCreateAPIView.as_view(), name='feedback-create'),

    # report endpoints
    path('reports/event-popularity/', EventPopularityReportAPIView.as_view(), name='report-event-popularity'),
    path('reports/attendance-percentage/', AttendancePercentageReportAPIView.as_view(), name='report-attendance-percentage'),
    path('reports/average-feedback/', AverageFeedbackReportAPIView.as_view(), name='report-average-feedback'),
]
