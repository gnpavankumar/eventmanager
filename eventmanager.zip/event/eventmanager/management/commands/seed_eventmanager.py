from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.db.models import Count, Q
from datetime import timedelta
import random

from eventmanager.models import College, Student, AdminProfile, Event, Registration, AttendanceLog, Feedback

User = get_user_model()

class Command(BaseCommand):
    help = 'Seed sample data for eventmanager and print sample reports'

    def add_arguments(self, parser):
        parser.add_argument('--colleges', type=int, default=3)
        parser.add_argument('--students-per-college', type=int, default=20)
        parser.add_argument('--events-per-college', type=int, default=5)

    def handle(self, *args, **options):
        C = options['colleges']
        S = options['students_per_college']
        E = options['events_per_college']

        self.stdout.write("Seeding data...")

        # Create colleges
        colleges = []
        for i in range(C):
            name = f"College {i+1}"
            college, _ = College.objects.get_or_create(college_code=f"C{i+1:03d}", defaults={'name': name})
            colleges.append(college)

        # Create users (admins + students)
        for college in colleges:
            admin_username = f"admin_{college.college_code}"
            if not User.objects.filter(username=admin_username).exists():
                u = User.objects.create_user(username=admin_username, email=f"{admin_username}@example.com", password='admin123', first_name='Admin', last_name=college.college_code)
                AdminProfile.objects.create(user=u, college=college)

            for s in range(S):
                uname = f"student_{college.college_code}_{s+1}"
                if not User.objects.filter(username=uname).exists():
                    u = User.objects.create_user(username=uname, email=f"{uname}@example.com", password='student123', first_name=f"Student{s+1}", last_name=college.college_code)
                    Student.objects.create(user=u, college=college, roll_number=f"R{college.college_code}{s+1:03d}", year_of_study=random.randint(1,4))

        # Create events
        for college in colleges:
            admin = AdminProfile.objects.filter(college=college).first()
            for e in range(E):
                start = timezone.now() + timedelta(days=random.randint(1,60))
                ev = Event.objects.create(
                    college=college,
                    created_by=admin.user if admin else None,
                    title=f"Event {e+1} - {college.college_code}",
                    description="Sample event",
                    event_type=random.choice([t[0] for t in Event.EVENT_TYPES]),
                    start_time=start,
                    end_time=start + timedelta(hours=3),
                    location="Main Hall",
                    capacity=random.randint(30,200),
                    status='active'
                )

        # Create registrations & attendance & feedback
        for ev in Event.objects.all():
            students = Student.objects.filter(college=ev.college)
            num = min(students.count(), max(1, int(ev.capacity * 0.4)))
            selected = random.sample(list(students), num)
            for st in selected:
                reg, _ = Registration.objects.get_or_create(student=st, event=ev)
                # random attendance
                if random.random() < 0.7:
                    reg.status = 'attended'
                    reg.check_in_time = ev.start_time + timedelta(minutes=random.randint(-10, 30))
                    reg.save()
                    AttendanceLog.objects.create(student=st, event=ev)
                    # random feedback
                    if random.random() < 0.6:
                        Feedback.objects.create(student=st, event=ev, rating=random.randint(3,5), comment="Good event")

        self.stdout.write(self.style.SUCCESS("Seeding finished."))

        # Print a few reports
        self.print_reports()

    def print_reports(self):
        self.stdout.write("\nTop 3 active students (by distinct events attended):")
        rows = Student.objects.annotate(attended=Count('registrations', filter=Q(registrations__status='attended'))).order_by('-attended')[:3]
        for r in rows:
            self.stdout.write(f"- {r.user.username} ({r.college.name}) attended {r.attended}")

        self.stdout.write("\nEvent types summary:")
        types = Event.objects.values('event_type').annotate(count=Count('id')).order_by('-count')
        for t in types:
            self.stdout.write(f"- {t['event_type']}: {t['count']}")
