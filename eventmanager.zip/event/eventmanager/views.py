from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import generics, permissions
from django.db.models import Count, Avg, Q
from django.shortcuts import get_object_or_404
from django.contrib.auth import get_user_model

from .models import College, Student, AdminProfile, Event, Registration, AttendanceLog, Feedback
from .serializers import (
    CollegeSerializer, StudentSerializer, AdminProfileSerializer, EventSerializer,
    RegistrationSerializer, AttendanceSerializer, FeedbackSerializer
)

User = get_user_model()

# Basic viewsets for CRUD (useful for seeding/admin)
class CollegeViewSet(viewsets.ModelViewSet):
    queryset = College.objects.all()
    serializer_class = CollegeSerializer
    permission_classes = [permissions.AllowAny]


class StudentViewSet(viewsets.ModelViewSet):
    queryset = Student.objects.select_related('user', 'college').all()
    serializer_class = StudentSerializer
    permission_classes = [permissions.AllowAny]


class AdminProfileViewSet(viewsets.ModelViewSet):
    queryset = AdminProfile.objects.select_related('user', 'college').all()
    serializer_class = AdminProfileSerializer
    permission_classes = [permissions.AllowAny]


class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all().order_by('-start_time')
    serializer_class = EventSerializer
    permission_classes = [permissions.AllowAny]

    @action(detail=False, methods=['get'])
    def popularity(self, request):
        qs = Event.objects.annotate(registrations_count=Count('registrations')).order_by('-registrations_count')
        serializer = self.get_serializer(qs, many=True)
        return Response(serializer.data)

    @action(detail=False, methods=['get'])
    def by_type(self, request):
        etype = request.query_params.get('event_type')
        qs = self.queryset
        if etype:
            qs = qs.filter(event_type=etype)
        serializer = self.get_serializer(qs, many=True)
        return Response(serializer.data)


class RegistrationViewSet(viewsets.ModelViewSet):
    queryset = Registration.objects.select_related('student__user', 'event').all()
    serializer_class = RegistrationSerializer
    permission_classes = [permissions.AllowAny]

    @action(detail=False, methods=['get'])
    def student_participation(self, request):
        # Return number of events attended (status='attended') per student
        rows = Student.objects.annotate(
            attended_events=Count('registrations', filter=Q(registrations__status='attended'))
        ).order_by('-attended_events')
        data = [
            {
                'student_id': s.id,
                'name': s.user.get_full_name() or s.user.username,
                'attended_events': s.attended_events
            } for s in rows
        ]
        return Response(data)

    @action(detail=False, methods=['get'])
    def top_active(self, request):
        limit = int(request.query_params.get('limit', 3))
        rows = Student.objects.annotate(
            attended_events=Count('registrations', filter=Q(registrations__status='attended'))
        ).order_by('-attended_events')[:limit]
        data = [
            {
                'student_id': s.id,
                'name': s.user.get_full_name() or s.user.username,
                'college': s.college.name,
                'attended_events': s.attended_events
            } for s in rows
        ]
        return Response(data)


class AttendanceCreateAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        # body: { "student": student_id, "event": event_id }
        student_id = request.data.get('student')
        event_id = request.data.get('event')
        student = get_object_or_404(Student, id=student_id)
        event = get_object_or_404(Event, id=event_id)

        # Optional: require registration before attendance
        if not Registration.objects.filter(student=student, event=event).exists():
            return Response({"error": "Student not registered for this event."}, status=status.HTTP_400_BAD_REQUEST)

        # mark registration as attended
        reg = Registration.objects.get(student=student, event=event)
        reg.status = 'attended'
        from django.utils import timezone
        reg.check_in_time = timezone.now()
        reg.save()

        # create attendance log
        att = AttendanceLog.objects.create(student=student, event=event)
        serializer = AttendanceSerializer(att)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class FeedbackCreateAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def post(self, request):
        # body: { "student": student_id, "event": event_id, "rating": int, "comment": str }
        student_id = request.data.get('student')
        event_id = request.data.get('event')
        student = get_object_or_404(Student, id=student_id)
        event = get_object_or_404(Event, id=event_id)

        # Optional: require registration & attendance
        if not Registration.objects.filter(student=student, event=event, status='attended').exists():
            return Response({"error": "Student did not attend the event."}, status=status.HTTP_400_BAD_REQUEST)

        data = {
            'student': student.id,
            'event': event.id,
            'rating': request.data.get('rating'),
            'comment': request.data.get('comment', '')
        }
        serializer = FeedbackSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Lightweight report APIs (alternate / additional)
class EventPopularityReportAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        qs = Event.objects.annotate(registrations_count=Count('registrations')).order_by('-registrations')
        data = [
            {
                'event_id': e.id,
                'title': e.title,
                'college': e.college.name,
                'event_type': e.event_type,
                'registrations': e.registrations
            } for e in qs
        ]
        return Response(data)


class AttendancePercentageReportAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        event_id = request.query_params.get('event_id')
        qs = Event.objects.all()
        if event_id:
            qs = qs.filter(id=event_id)
        res = []
        for e in qs:
            res.append({
                'event_id': e.id,
                'title': e.title,
                'registrations': e.registrations_count,
                'attendance_percentage': e.attendance_percentage
            })
        return Response(res)


class AverageFeedbackReportAPIView(APIView):
    permission_classes = [permissions.AllowAny]

    def get(self, request):
        event_id = request.query_params.get('event_id')
        qs = Event.objects.all()
        if event_id:
            qs = qs.filter(id=event_id)
        data = []
        for e in qs:
            data.append({
                'event_id': e.id,
                'title': e.title,
                'average_feedback': e.average_feedback
            })
        return Response(data)
