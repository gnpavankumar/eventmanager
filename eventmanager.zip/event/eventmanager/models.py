from django.db import models
from django.conf import settings

User = getattr(settings, "AUTH_USER_MODEL", "auth.User")


class College(models.Model):
    name = models.CharField(max_length=255, unique=True)
    college_code = models.CharField(max_length=50, unique=True, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    contact_email = models.EmailField(blank=True, null=True)

    def __str__(self):
        return self.name


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="student_profile")
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name="students")
    roll_number = models.CharField(max_length=50, blank=True, null=True)
    year_of_study = models.IntegerField(blank=True, null=True)

    def __str__(self):
        return f"{self.user.get_full_name() or self.user.username} ({self.college.name})"


class AdminProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="admin_profile")
    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name="admins")

    def __str__(self):
        return f"Admin: {self.user.get_full_name() or self.user.username} ({self.college.name})"


class Event(models.Model):
    EVENT_TYPES = [
        ('hackathon', 'Hackathon'),
        ('workshop', 'Workshop'),
        ('fest', 'Fest'),
        ('seminar', 'Seminar'),
        ('conference', 'Conference'),
    ]

    college = models.ForeignKey(College, on_delete=models.CASCADE, related_name="events")
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name="created_events")
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    event_type = models.CharField(max_length=50, choices=EVENT_TYPES)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    location = models.CharField(max_length=255, blank=True)
    capacity = models.PositiveIntegerField(null=True, blank=True)
    status = models.CharField(max_length=20, default="active")  # active, cancelled, completed

    def __str__(self):
        return f"{self.title} ({self.college.name})"

    @property
    def registrations_count(self):
        return self.registrations.count()

    @property
    def attendance_percentage(self):
        regs = self.registrations.count()
        if regs == 0:
            return 0.0
        attended = self.registrations.filter(status='attended').count()
        return round(attended / regs * 100.0, 2)

    @property
    def average_feedback(self):
        qs = self.feedbacks.all()
        if not qs.exists():
            return None
        return round(qs.aggregate(models.Avg('rating'))['rating__avg'], 2)


class Registration(models.Model):
    STATUS_CHOICES = [
        ('registered', 'Registered'),
        ('attended', 'Attended'),
        ('cancelled', 'Cancelled'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="registrations")
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="registrations")
    registered_at = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='registered')
    check_in_time = models.DateTimeField(null=True, blank=True)

    class Meta:
        unique_together = ('student', 'event')

    def __str__(self):
        return f"{self.student.user.get_full_name() or self.student.user.username} -> {self.event.title} ({self.status})"


class AttendanceLog(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="attendance_logs")
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="attendance_logs")
    check_in_time = models.DateTimeField(auto_now_add=True)
    # optional: session_name = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        unique_together = ('student', 'event', 'check_in_time')  # allows multiple separate check-ins but unique per timestamp

    def __str__(self):
        return f"{self.student.user.get_full_name() or self.student.user.username} @ {self.event.title} on {self.check_in_time}"


class Feedback(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE, related_name="feedbacks")
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="feedbacks")
    rating = models.PositiveSmallIntegerField()  # 1..5 enforced in serializer
    comment = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('student', 'event')

    def __str__(self):
        return f"{self.student.user.username} => {self.event.title}: {self.rating}"
