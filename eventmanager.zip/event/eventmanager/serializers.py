from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import (
    College, Student, AdminProfile, Event, Registration, AttendanceLog, Feedback
)

User = get_user_model()


class UserSimpleSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'first_name', 'last_name', 'email']


class CollegeSerializer(serializers.ModelSerializer):
    class Meta:
        model = College
        fields = ['id', 'college_code', 'name', 'address', 'contact_email']


class StudentSerializer(serializers.ModelSerializer):
    user = UserSimpleSerializer()

    class Meta:
        model = Student
        fields = ['id', 'user', 'college', 'roll_number', 'year_of_study']
        read_only_fields = ['id']


class AdminProfileSerializer(serializers.ModelSerializer):
    user = UserSimpleSerializer()

    class Meta:
        model = AdminProfile
        fields = ['id', 'user', 'college']
        read_only_fields = ['id']


class EventSerializer(serializers.ModelSerializer):
    registrations_count = serializers.IntegerField( read_only=True)
    attendance_percentage = serializers.FloatField( read_only=True)
    average_feedback = serializers.FloatField( read_only=True)

    class Meta:
        model = Event
        fields = [
            'id', 'college', 'created_by', 'title', 'description', 'event_type',
            'start_time', 'end_time', 'location', 'capacity', 'status',
            'registrations_count', 'attendance_percentage', 'average_feedback'
        ]
        read_only_fields = ['id', 'registrations_count', 'attendance_percentage', 'average_feedback']


class RegistrationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Registration
        fields = ['id', 'student', 'event', 'registered_at', 'status', 'check_in_time']
        read_only_fields = ['id', 'registered_at']


class AttendanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = AttendanceLog
        fields = ['id', 'student', 'event', 'check_in_time']
        read_only_fields = ['id', 'check_in_time']


class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = Feedback
        fields = ['id', 'student', 'event', 'rating', 'comment', 'submitted_at']
        read_only_fields = ['id', 'submitted_at']

    def validate_rating(self, value):
        if value < 1 or value > 5:
            raise serializers.ValidationError("Rating must be between 1 and 5.")
        return value

